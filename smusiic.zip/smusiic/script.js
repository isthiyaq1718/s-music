  const playlists = {
    'Liked Songs': {meta:'Auto playlist • 143 songs', colors:['#5F4B8B','#26D0CE'], tracks:[
      ['Amber Skyline','Marlow & the Tides'],['Neon Static','Coral House'],['Slow Bloom','June Radio'],
      ['Paper Lanterns','Dusk Signal'],['Glass Coast','Ivory Wolves']
    ]},
    'Focus Flow': {meta:'Playlist • Deep work', colors:['#1F4037','#99F2C8'], tracks:[
      ['Quiet Engine','Studio Loom'],['Low Light','Field Theory'],['Grey Matter','Nils Aker'],['Even Keel','Studio Loom']
    ]},
    'Sunset Drive': {meta:'Playlist • Golden hour', colors:['#F5C453','#E0575B'], tracks:[
      ['Amber Skyline','Marlow & the Tides'],['Coastal Run','Marlow & the Tides'],['Warm Static','Coral House'],
      ['Last Light','June Radio'],['Overdrive','Ivory Wolves']
    ]},
    'Rainy Room': {meta:'Playlist • Lo-fi calm', colors:['#485563','#29323C'], tracks:[
      ['Windowpane','Field Theory'],['Grey Matter','Nils Aker'],['Soft Static','Dusk Signal']
    ]},
    'Daily Mix 1': {meta:'Made for you', colors:['#4E7AC7','#7A3FA0'], tracks:[
      ['Neon Static','Coral House'],['Paper Lanterns','Dusk Signal'],['Quiet Engine','Studio Loom']
    ]},
    'Discover Weekly': {meta:'Made for you', colors:['#E85D75','#F2A65A'], tracks:[
      ['Glass Coast','Ivory Wolves'],['Coastal Run','Marlow & the Tides'],['Even Keel','Studio Loom']
    ]},
    'The Daily Debrief': {meta:'Podcast • News & culture', colors:['#2C3E50','#4CA1AF'], type:'podcast', tracks:[
      ['Ep 214: Market Watch','The Daily Debrief'],['Ep 213: The Long Read','The Daily Debrief'],['Ep 212: Weekend Wrap','The Daily Debrief']
    ]},
    'Mindful Minutes': {meta:'Podcast • Wellness', colors:['#7F5A83','#0D324D'], type:'podcast', tracks:[
      ['Breathing Basics','Mindful Minutes'],['Letting Go','Mindful Minutes'],['Evening Wind-down','Mindful Minutes']
    ]},
    'City Sessions Live': {meta:'Live • Streaming now', colors:['#C31432','#240B36'], type:'live', tracks:[
      ['Live Set — Opening','City Sessions'],['Live Set — Peak Hour','City Sessions']
    ]},
    'Michael Jackson': {meta:'Playlist • King of Pop', colors:['#C31432','#240B36'], tracks:[
      ['Beat It','Michael Jackson','https://soundcloud.com/darion-lopez-38557354/beat-it-michael-jackson'],
      ['Smooth Criminal','Michael Jackson','https://soundcloud.com/umarkx/michael-jackson-smooth-criminal'],
      ['Billie Jean','Michael Jackson','https://soundcloud.com/maitre80/billie-jean-michael-jackson'],
      ['Human Nature','Michael Jackson','https://soundcloud.com/nicoleobara/human-nature-michael-jackson'],
      ["They Don't Care About Us",'Michael Jackson','https://soundcloud.com/michael-jackson-881677963/they-dont-care-about-us-audio-oficial-2'],
      ['Thriller','Michael Jackson','https://soundcloud.com/mrkakarot-beastgamer23/michael-jackson-thriller']
    ]}
  };

  let currentPlaylist = 'Sunset Drive';
  let currentTrackIndex = 0;
  // BUG FIX: was previously an undeclared global (implicit `window.isLoggedIn`),
  // which throws a ReferenceError in strict mode and is bad practice generally.
  let isLoggedIn = false;
  // BUG FIX: tracks whether *anything* (audio track, YouTube embed, or
  // SoundCloud embed) has ever been loaded, so expandNowPlaying() can work
  // correctly for embeds too (previously it only checked audioEl.src, so
  // clicking the mini-player while a YouTube/SoundCloud embed was playing
  // silently did nothing on desktop).
  let hasLoadedTrack = false;

  // Royalty-free demo tracks standing in for real song audio (no licensed
  // music is used). Each fictional song title deterministically maps to one
  // of these so the same "song" always plays the same demo clip.
  const demoTracks = [
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3'
  ];
  function trackSrc(title){
    let hash = 0;
    for (let i = 0; i < title.length; i++){ hash = (hash * 31 + title.charCodeAt(i)) >>> 0; }
    return demoTracks[hash % demoTracks.length];
  }

  const audioEl = document.getElementById('audio-el');
  const isDesktop = () => window.matchMedia('(min-width:900px)').matches;
  let playbackMode = 'audio'; // 'audio' | 'youtube' | 'soundcloud'
  let scWidget = null;
  let scDurationMs = 0;

  // ---- Firebase Storage: pull in every song file uploaded to the bucket ----
  // 1. Create a free Firebase project (firebase.google.com) and enable Storage.
  // 2. Paste your project's config below (Project settings > General > Your apps).
  // 3. Upload audio files under a "songs/" folder in the Storage console.
  //    Optional: set custom metadata "title" and "artist" on each file, or the
  //    filename (minus extension) is used as the title.
  // 4. Set Storage rules to allow public read if you want this page to load
  //    without login, e.g.: allow read: if true;
  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
  };

  let firebaseReady = false;
  try {
    if (firebaseConfig.apiKey !== "YOUR_API_KEY") {
      firebase.initializeApp(firebaseConfig);
      firebaseReady = true;
    }
  } catch (e) { console.warn('Firebase init skipped:', e); }

  async function loadSongsFromFirebase(){
    if (!firebaseReady) return;
    try {
      const storage = firebase.storage();
      const folderRef = storage.ref('songs');
      const listing = await folderRef.listAll();
      const palette = [['#4E7AC7','#7A3FA0'],['#E85D75','#F2A65A'],['#1F4037','#99F2C8'],['#C31432','#240B36'],['#5F4B8B','#26D0CE']];

      for (const itemRef of listing.items){
        const [url, meta] = await Promise.all([itemRef.getDownloadURL(), itemRef.getMetadata()]);
        const custom = meta.customMetadata || {};
        const fallbackTitle = itemRef.name.replace(/\.[^/.]+$/, '');
        const c = palette[songDatabase.length % palette.length];
        addSongToDatabase({
          id: 'fb-' + itemRef.fullPath,
          title: custom.title || fallbackTitle,
          artist: custom.artist || 'Unknown Artist',
          duration: '--:--',
          c1: c[0], c2: c[1],
          audioUrl: url
        });
      }
      renderSearch();
    } catch (e) {
      console.warn('Could not load songs from Firebase Storage:', e);
    }
  }

  const songDatabase = [
    { id: 1, title: 'Imagine', artist: 'John Lennon', duration: '3:03', c1: '#FF6B6B', c2: '#FFE66D' },
    { id: 2, title: 'Bohemian Rhapsody', artist: 'Queen', duration: '5:55', c1: '#4E7AC7', c2: '#7A3FA0' },
    { id: 3, title: 'Hotel California', artist: 'Eagles', duration: '6:30', c1: '#E85D75', c2: '#F2A65A' },
    { id: 4, title: 'Stairway to Heaven', artist: 'Led Zeppelin', duration: '8:02', c1: '#1F4037', c2: '#99F2C8' },
    { id: 5, title: 'What a Wonderful World', artist: 'Louis Armstrong', duration: '2:21', c1: '#F5C453', c2: '#E0575B' },
    { id: 6, title: "Sweet Child o' Mine", artist: "Guns N' Roses", duration: '5:56', c1: '#5F4B8B', c2: '#26D0CE' },
    { id: 7, title: 'Smells Like Teen Spirit', artist: 'Nirvana', duration: '5:01', c1: '#485563', c2: '#29323C' },
    { id: 8, title: 'Purple Haze', artist: 'Jimi Hendrix', duration: '3:36', c1: '#7F5A83', c2: '#0D324D' },
    { id: 9, title: 'Rowdy Baby', artist: 'Dhanush, Dhee', duration: '4:44', c1: '#C31432', c2: '#240B36', youtubeId: 'x6Q7c9RyMzk' },
    { id: 10, title: 'Vaathi Coming', artist: 'Anirudh Ravichander', duration: '3:50', c1: '#1F4037', c2: '#F5C453', youtubeId: 'q3fUYSgBf-k' },
    { id: 11, title: 'Beat It', artist: 'Michael Jackson', duration: '--:--', c1: '#4E7AC7', c2: '#7A3FA0', soundcloudUrl: 'https://soundcloud.com/darion-lopez-38557354/beat-it-michael-jackson' },
    { id: 12, title: 'Smooth Criminal', artist: 'Michael Jackson', duration: '--:--', c1: '#E85D75', c2: '#F2A65A', soundcloudUrl: 'https://soundcloud.com/umarkx/michael-jackson-smooth-criminal' },
    { id: 13, title: 'Billie Jean', artist: 'Michael Jackson', duration: '--:--', c1: '#1F4037', c2: '#99F2C8', soundcloudUrl: 'https://soundcloud.com/maitre80/billie-jean-michael-jackson' },
    { id: 14, title: 'Human Nature', artist: 'Michael Jackson', duration: '--:--', c1: '#5F4B8B', c2: '#26D0CE', soundcloudUrl: 'https://soundcloud.com/nicoleobara/human-nature-michael-jackson' },
    { id: 15, title: "They Don't Care About Us", artist: 'Michael Jackson', duration: '--:--', c1: '#485563', c2: '#29323C', soundcloudUrl: 'https://soundcloud.com/michael-jackson-881677963/they-dont-care-about-us-audio-oficial-2' },
    { id: 16, title: 'Thriller', artist: 'Michael Jackson', duration: '--:--', c1: '#7F5A83', c2: '#0D324D', soundcloudUrl: 'https://soundcloud.com/mrkakarot-beastgamer23/michael-jackson-thriller' }
  ];

  // Generic free-embed playback: works for a YouTube video id or a
  // public SoundCloud track URL. Both platforms let you embed their own
  // player for free for content the uploader has made publicly shareable —
  // no file hosting or audio hotlinking required.
  function playEmbed(type, idOrUrl, title, artist){
    // BUG FIX: previously the <audio> element was never paused/cleared when
    // switching to a YouTube/SoundCloud embed, so if a normal track was
    // already playing it kept playing underneath the embed's own audio —
    // two songs would play at once.
    audioEl.pause();
    audioEl.src = '';
    hasLoadedTrack = true;
    playbackMode = type;
    scWidget = null;
    scDurationMs = 0;
    document.getElementById('np-song').textContent = title;
    document.getElementById('np-artist').textContent = artist;
    document.getElementById('np-from').textContent = type === 'youtube' ? 'YouTube' : 'SoundCloud';
    document.getElementById('np-art').style.display = 'none';
    document.getElementById('yt-embed-wrap').style.display = 'block';
    document.getElementById('mb-song').textContent = title;
    document.getElementById('mb-artist').textContent = artist;
    document.getElementById('mb-art').style.background = 'linear-gradient(135deg,#4E7AC7,#7A3FA0)';
    const ytFrame = document.getElementById('yt-frame');
    const scFrame = document.getElementById('sc-frame');

    if (type === 'youtube'){
      scFrame.style.display = 'none'; scFrame.src = '';
      ytFrame.style.display = 'block';
      ytFrame.src = `https://www.youtube.com/embed/${idOrUrl}?autoplay=1`;
      document.getElementById('np-progress-wrap').style.display = 'none';
      document.getElementById('np-controls-wrap').style.display = 'none';
    } else {
      // SoundCloud: "visual" mode shows the track's real cover art
      // full-bleed inside the iframe. On top of that we drive our own
      // scrub bar and play/pause/prev/next via the SoundCloud Widget
      // API, so forward/backward dragging works the same way it does
      // for regular playlist tracks.
      ytFrame.style.display = 'none'; ytFrame.src = '';
      scFrame.style.display = 'block';
      scFrame.src = `https://w.soundcloud.com/player/?url=${encodeURIComponent(idOrUrl)}&auto_play=true&color=%231ED760&visual=true&show_artwork=true&show_user=false&show_reposts=false&show_comments=false&show_teaser=false&sharing=false&buying=false&download=false`;

      document.getElementById('np-progress-wrap').style.display = 'block';
      document.getElementById('np-controls-wrap').style.display = 'flex';
      document.getElementById('np-fill').style.width = '0%';
      document.getElementById('mb-fill').style.width = '0%';

      scFrame.onload = () => {
        if (typeof SC === 'undefined') return;
        const widget = SC.Widget(scFrame);
        scWidget = widget;
        widget.bind(SC.Widget.Events.READY, () => {
          widget.getCurrentSound((sound) => {
            if (sound && sound.artwork_url){
              const hiRes = sound.artwork_url.replace('-large', '-t500x500');
              document.getElementById('mb-art').style.backgroundImage = `url("${hiRes}")`;
              document.getElementById('mb-art').style.backgroundSize = 'cover';
              document.getElementById('mb-art').style.backgroundPosition = 'center';
            }
          });
          widget.getDuration((ms) => {
            scDurationMs = ms;
            document.getElementById('np-duration').textContent = fmtTime(ms / 1000);
            document.getElementById('mb-duration').textContent = fmtTime(ms / 1000);
          });
        });
        widget.bind(SC.Widget.Events.PLAY_PROGRESS, (e) => {
          if (isSeeking || playbackMode !== 'soundcloud') return;
          const pct = e.relativePosition * 100;
          document.getElementById('np-fill').style.width = pct + '%';
          document.getElementById('mb-fill').style.width = pct + '%';
          document.getElementById('np-elapsed').textContent = fmtTime(e.currentPosition / 1000);
          document.getElementById('mb-elapsed').textContent = fmtTime(e.currentPosition / 1000);
        });
        widget.bind(SC.Widget.Events.PLAY, () => setPlayingIcons(true));
        widget.bind(SC.Widget.Events.PAUSE, () => setPlayingIcons(false));
        widget.bind(SC.Widget.Events.FINISH, () => nextTrack());
      };
    }
    if (isDesktop()) expandNowPlaying(); else goTo('nowplaying');
  }
  // Direct file playback (e.g. from Firebase Storage) — uses the real
  // seekable audio player, same as playlist tracks, instead of an embed.
  function playDirectAudio(url, title, artist){
    hasLoadedTrack = true;
    playbackMode = 'audio';
    scWidget = null;
    scDurationMs = 0;
    document.getElementById('sc-frame').src = '';
    document.getElementById('yt-frame').src = '';
    document.getElementById('yt-embed-wrap').style.display = 'none';
    document.getElementById('np-art').style.display = 'block';
    document.getElementById('np-art').style.backgroundImage = 'none';
    document.getElementById('mb-art').style.backgroundImage = 'none';
    document.getElementById('np-progress-wrap').style.display = 'block';
    document.getElementById('np-controls-wrap').style.display = 'flex';

    document.getElementById('np-song').textContent = title;
    document.getElementById('np-artist').textContent = artist;
    document.getElementById('np-from').textContent = 'Your Library';
    document.getElementById('np-art').style.background = 'linear-gradient(135deg,#4E7AC7,#7A3FA0)';

    document.getElementById('mb-song').textContent = title;
    document.getElementById('mb-artist').textContent = artist;
    document.getElementById('mb-art').style.background = 'linear-gradient(135deg,#4E7AC7,#7A3FA0)';

    currentPlaylist = null;
    audioEl.src = url;
    audioEl.currentTime = 0;
    audioEl.play().catch(() => {});
    setPlayingIcons(true);
    if (isDesktop()) expandNowPlaying(); else goTo('nowplaying');
  }

  function playYouTube(id, title, artist){ playEmbed('youtube', id, title, artist); }

  function stopYouTubeEmbed(){
    playbackMode = 'audio';
    scWidget = null;
    scDurationMs = 0;
    document.getElementById('yt-frame').src = '';
    document.getElementById('sc-frame').src = '';
    document.getElementById('yt-embed-wrap').style.display = 'none';
    document.getElementById('np-art').style.display = 'block';
    document.getElementById('np-art').style.backgroundImage = 'none';
    document.getElementById('mb-art').style.backgroundImage = 'none';
    document.getElementById('np-progress-wrap').style.display = 'block';
    document.getElementById('np-controls-wrap').style.display = 'flex';
  }

  // ---- URL parsing for the Add Song form ----
  function parseYouTubeId(url){
    const m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
    return m ? m[1] : null;
  }
  function isSoundCloudTrackUrl(url){
    return /^https?:\/\/(www\.)?soundcloud\.com\/[^/]+\/[^/]+/i.test(url.trim());
  }

  function openAddSongModal(){
    document.getElementById('as-title').value = '';
    document.getElementById('as-artist').value = '';
    document.getElementById('as-url').value = '';
    document.getElementById('as-error').textContent = '';
    document.getElementById('add-song-modal').style.display = 'flex';
  }
  function closeAddSongModal(){
    document.getElementById('add-song-modal').style.display = 'none';
  }

  function submitAddSong(){
    const title = document.getElementById('as-title').value.trim();
    const artist = document.getElementById('as-artist').value.trim();
    const url = document.getElementById('as-url').value.trim();
    const errEl = document.getElementById('as-error');

    if (!title || !artist || !url){
      errEl.textContent = 'Fill in title, artist, and a URL.';
      return;
    }

    const ytId = parseYouTubeId(url);
    const isSc = isSoundCloudTrackUrl(url);
    const isDirectAudio = /\.(mp3|wav|m4a|ogg|aac|flac)(\?|$)/i.test(url) || url.includes('firebasestorage.googleapis.com');
    if (!ytId && !isSc && !isDirectAudio){
      errEl.textContent = "That doesn't look like a YouTube, SoundCloud, or audio file link.";
      return;
    }

    const palette = [['#4E7AC7','#7A3FA0'],['#E85D75','#F2A65A'],['#1F4037','#99F2C8'],['#C31432','#240B36'],['#5F4B8B','#26D0CE']];
    const c = palette[songDatabase.length % palette.length];
    const entry = {
      id: Date.now(),
      title, artist,
      duration: '--:--',
      c1: c[0], c2: c[1]
    };
    if (ytId) entry.youtubeId = ytId;
    else if (isSc) entry.soundcloudUrl = url;
    else entry.audioUrl = url;

    addSongToDatabase(entry);
    closeAddSongModal();
    document.getElementById('search-input').value = title;
    renderSearch();
  }

  function openSongOnPlatform(title, artist, platform){
    const q = encodeURIComponent(title + ' ' + artist);
    const platforms = {
      spotify: `https://open.spotify.com/search/${q}`,
      youtube: `https://www.youtube.com/results?search_query=${q}`,
      apple_music: `https://music.apple.com/search?term=${q}`
    };
    window.open(platforms[platform], '_blank');
  }

  function addSongToDatabase(songData){
    if (!songData.id || !songData.title || !songData.artist) return false;
    songDatabase.push(songData);
    return true;
  }

  function renderSongResults(query){
    const wrap = document.getElementById('song-results');
    const q = query.toLowerCase();
    const matches = q ? songDatabase.filter(s => s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q)) : [];
    if (!matches.length){ wrap.innerHTML = ''; return; }
    wrap.innerHTML = '<div class="screen-heading" style="font-size:15px; padding:14px 20px 4px;">Songs</div>' +
      matches.map(s => `
        <div class="list-row" style="align-items:center;">
          <div class="sw" style="--c1:${s.c1}; --c2:${s.c2};"></div>
          <div class="info" style="flex:1;"><div class="t">${s.title}</div><div class="a">${s.artist} • ${s.duration}</div></div>
          <div style="display:flex; gap:6px;">
            ${s.youtubeId ? `<button class="auth-btn logged-in" style="padding:5px 10px; font-size:11px;" onclick="event.stopPropagation(); playEmbed('youtube','${s.youtubeId}','${s.title.replace(/'/g,"\\'")}','${s.artist.replace(/'/g,"\\'")}')">▶ Play Free</button>` : ''}
            ${s.soundcloudUrl ? `<button class="auth-btn logged-in" style="padding:5px 10px; font-size:11px;" onclick="event.stopPropagation(); playEmbed('soundcloud','${s.soundcloudUrl.replace(/'/g,"\\'")}','${s.title.replace(/'/g,"\\'")}','${s.artist.replace(/'/g,"\\'")}')">▶ Play Free</button>` : ''}
            ${s.audioUrl ? `<button class="auth-btn logged-in" style="padding:5px 10px; font-size:11px;" onclick="event.stopPropagation(); playDirectAudio('${s.audioUrl.replace(/'/g,"\\'")}','${s.title.replace(/'/g,"\\'")}','${s.artist.replace(/'/g,"\\'")}')">▶ Play</button>` : ''}
            <button class="auth-btn" style="padding:5px 10px; font-size:11px;" onclick="event.stopPropagation(); openSongOnPlatform('${s.title.replace(/'/g,"\\'")}','${s.artist.replace(/'/g,"\\'")}','spotify')">Spotify</button>
            <button class="auth-btn" style="padding:5px 10px; font-size:11px;" onclick="event.stopPropagation(); openSongOnPlatform('${s.title.replace(/'/g,"\\'")}','${s.artist.replace(/'/g,"\\'")}','youtube')">YouTube</button>
          </div>
        </div>`).join('');
  }
  let currentFilter = 'all';
  const favorites = new Set();

  function goTo(screenName, plName, plMeta, plColors){
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-' + screenName).classList.add('active');

    // bottom nav active state (home/search/library only live in the tab bar)
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navMap = {home:'nav-home', search:'nav-search', library:'nav-library'};
    if (navMap[screenName]) document.getElementById(navMap[screenName]).classList.add('active');

    // sidebar active state (desktop)
    document.querySelectorAll('.side-link').forEach(n => n.classList.remove('active'));
    const sideMap = {home:'side-home', search:'side-search', library:'side-library'};
    if (sideMap[screenName]) document.getElementById(sideMap[screenName]).classList.add('active');

    if (screenName === 'playlist' && plName){
      currentPlaylist = plName;
      renderPlaylist(plName, plMeta, plColors);
    }
    if (screenName === 'search') renderSearch();
    if (screenName === 'library') renderLibrary();
    if (screenName === 'favorites') renderFavorites();

    document.querySelector('.main').scrollTop = 0;
    const activeScreen = document.getElementById('screen-' + screenName);
    if (activeScreen) activeScreen.scrollTop = 0;
  }

  function setFilter(type){
    currentFilter = type;
    document.querySelectorAll('#filter-row .chip').forEach(c => c.classList.toggle('on', c.dataset.filter === type));
    document.querySelectorAll('.quick-card, .h-scroll .card').forEach(el => {
      const t = el.dataset.type || 'music';
      el.classList.toggle('hide', type !== 'all' && t !== type);
    });
  }

  const GOOGLE_CLIENT_ID = '263033121547-s86enj3he0pf7e6tq1l9hehd1odpa3b6.apps.googleusercontent.com';

  function decodeJwt(token){
    try {
      const payload = token.split('.')[1];
      const json = decodeURIComponent(atob(payload.replace(/-/g,'+').replace(/_/g,'/'))
        .split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
      return JSON.parse(json);
    } catch(e){ return null; }
  }

  function handleCredentialResponse(response){
    const profile = decodeJwt(response.credential);
    if (!profile) return;
    isLoggedIn = true;
    document.getElementById('greeting-el').textContent = 'Good evening, ' + (profile.given_name || profile.name || 'there');
    const avatarEl = document.getElementById('avatar-el');
    if (profile.picture){
      avatarEl.style.backgroundImage = `url(${profile.picture})`;
      avatarEl.style.backgroundSize = 'cover';
      avatarEl.textContent = '';
    } else {
      avatarEl.textContent = (profile.given_name || 'U')[0].toUpperCase();
    }
    document.getElementById('google-signin-btn').style.display = 'none';
    document.getElementById('logout-btn').style.display = 'inline-block';
  }

  function logout(){
    isLoggedIn = false;
    favorites.clear();
    google.accounts.id.disableAutoSelect();
    document.getElementById('greeting-el').textContent = 'Good evening, Guest';
    const avatarEl = document.getElementById('avatar-el');
    avatarEl.style.backgroundImage = '';
    avatarEl.textContent = '?';
    document.getElementById('logout-btn').style.display = 'none';
    document.getElementById('google-signin-btn').style.display = 'block';
    goTo('home');
  }

  window.addEventListener('load', () => {
    if (typeof google === 'undefined' || !google.accounts) return;
    google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: handleCredentialResponse
    });
    google.accounts.id.renderButton(
      document.getElementById('google-signin-btn'),
      { theme: 'filled_black', size: 'medium', shape: 'pill', text: 'signin', width: 130 }
    );
  });

  function toggleFavorite(name){
    if (!name) return;
    if (favorites.has(name)) favorites.delete(name); else favorites.add(name);
    updateHeartIcons();
    const favScreen = document.getElementById('screen-favorites');
    if (favScreen.classList.contains('active')) renderFavorites();
  }

  function updateHeartIcons(){
    const isFav = favorites.has(currentPlaylist);
    ['pl-heart','np-heart'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.setAttribute('fill', isFav ? '#1ED760' : 'none');
    });
  }

  function renderRowsInto(containerId, names, emptyText){
    const wrap = document.getElementById(containerId);
    wrap.innerHTML = '';
    if (!names.length){
      wrap.innerHTML = `<div class="empty-state">${emptyText}</div>`;
      return;
    }
    names.forEach(name => {
      const data = playlists[name];
      if (!data) return;
      const row = document.createElement('div');
      row.className = 'list-row';
      row.onclick = () => goTo('playlist', name, data.meta, data.colors);
      row.innerHTML = `<div class="sw" style="--c1:${data.colors[0]}; --c2:${data.colors[1]};"></div>
        <div class="info"><div class="t">${name}</div><div class="a">${data.meta}</div></div>`;
      wrap.appendChild(row);
    });
  }

  function renderLibrary(){
    renderRowsInto('library-list', Object.keys(playlists), 'Your library is empty.');
  }

  function renderFavorites(){
    renderRowsInto('favorites-list', Array.from(favorites), 'No favorites yet — tap the heart on a playlist to save it here.');
  }

  function renderSearch(){
    const q = (document.getElementById('search-input').value || '').trim().toLowerCase();
    const names = Object.keys(playlists).filter(name => {
      if (!q) return true;
      const data = playlists[name];
      return name.toLowerCase().includes(q) || (data.meta || '').toLowerCase().includes(q);
    });
    renderRowsInto('search-results', names, 'No results found.');
    renderSongResults(q);
  }

  function renderSidebarPlaylists(){
    const wrap = document.getElementById('side-playlists');
    wrap.innerHTML = '';
    Object.keys(playlists).forEach(name => {
      const data = playlists[name];
      const item = document.createElement('div');
      item.className = 'side-pl-item';
      item.onclick = () => goTo('playlist', name, data.meta, data.colors);
      item.innerHTML = `<div class="sw" style="--c1:${data.colors[0]}; --c2:${data.colors[1]};"></div><span>${name}</span>`;
      wrap.appendChild(item);
    });
  }

  function renderPlaylist(name, meta, colors){
    const data = playlists[name] || {meta:meta, colors:colors, tracks:[]};
    document.getElementById('pl-title').textContent = name;
    document.getElementById('pl-meta').textContent = meta || data.meta;
    const c = colors || data.colors;
    document.getElementById('pl-cover').style.background = `linear-gradient(135deg, ${c[0]}, ${c[1]})`;
    document.getElementById('pl-header').style.background = `linear-gradient(180deg, ${c[0]} 0%, var(--bg) 340px)`;

    const list = document.getElementById('track-list');
    list.innerHTML = '';
    data.tracks.forEach((t, i) => {
      const row = document.createElement('div');
      row.className = 'track-row';
      row.id = `row-${name}-${i}`;
      row.onclick = () => selectTrack(name, i);
      row.innerHTML = `
        <div class="num">${i+1}</div>
        <div class="art-sm" style="--c1:${c[0]}; --c2:${c[1]};"></div>
        <div class="info"><div class="t">${t[0]}</div><div class="a">${t[1]}</div></div>`;
      list.appendChild(row);
    });
    highlightActiveRow();
    updateHeartIcons();
  }

  function highlightActiveRow(){
    document.querySelectorAll('.track-row').forEach(r => r.classList.remove('playing'));
    const active = document.getElementById(`row-${currentPlaylist}-${currentTrackIndex}`);
    if (active) active.classList.add('playing');
  }

  function fmtTime(sec){
    if (!isFinite(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  function selectTrack(playlistName, index){
    loadAndPlay(playlistName, index);
    if (!isDesktop()) goTo('nowplaying');
  }

  function loadAndPlay(playlistName, index){
    hasLoadedTrack = true;
    currentPlaylist = playlistName;
    currentTrackIndex = index;
    const data = playlists[playlistName];
    const t = data.tracks[index];

    if (t[2]){
      stopYouTubeEmbed();
      playEmbed('soundcloud', t[2], t[0], t[1]);
      highlightActiveRow();
      return;
    }

    const grad = `linear-gradient(135deg, ${data.colors[0]}, ${data.colors[1]})`;

    playbackMode = 'audio';
    scWidget = null;
    scDurationMs = 0;
    document.getElementById('sc-frame').src = '';
    document.getElementById('yt-frame').src = '';
    document.getElementById('np-art').style.backgroundImage = 'none';
    document.getElementById('mb-art').style.backgroundImage = 'none';

    document.getElementById('np-song').textContent = t[0];
    document.getElementById('np-artist').textContent = t[1];
    document.getElementById('np-from').textContent = playlistName;
    document.getElementById('np-art').style.background = grad;
    document.getElementById('np-art').style.display = 'block';
    document.getElementById('np-progress-wrap').style.display = 'block';
    document.getElementById('np-controls-wrap').style.display = 'flex';
    document.getElementById('yt-embed-wrap').style.display = 'none';

    document.getElementById('mb-song').textContent = t[0];
    document.getElementById('mb-artist').textContent = t[1];
    document.getElementById('mb-art').style.background = grad;

    audioEl.src = trackSrc(t[0]);
    audioEl.currentTime = 0;
    audioEl.play().catch(() => {});
    setPlayingIcons(true);
    highlightActiveRow();
  }

  function togglePlay(){
    if (playbackMode === 'soundcloud' && scWidget){
      scWidget.isPaused((paused) => { if (paused) scWidget.play(); else scWidget.pause(); });
      return;
    }
    if (!audioEl.src) return;
    if (audioEl.paused){ audioEl.play().catch(() => {}); setPlayingIcons(true); }
    else { audioEl.pause(); setPlayingIcons(false); }
  }

  function setPlayingIcons(isPlaying){
    const pauseIcon = '<rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/>';
    const playIcon = '<path d="M8 5v14l11-7z"/>';
    document.getElementById('np-playicon').innerHTML = isPlaying ? pauseIcon : playIcon;
    document.getElementById('mb-playicon').innerHTML = isPlaying ? pauseIcon : playIcon;
  }

  function nextTrack(){
    const data = playlists[currentPlaylist];
    loadAndPlay(currentPlaylist, (currentTrackIndex + 1) % data.tracks.length);
  }
  function prevTrack(){
    const data = playlists[currentPlaylist];
    loadAndPlay(currentPlaylist, (currentTrackIndex - 1 + data.tracks.length) % data.tracks.length);
  }

  function expandNowPlaying(){
    // BUG FIX: this used to check `!audioEl.src`, so expanding the
    // now-playing view (e.g. clicking the desktop mini-player) silently did
    // nothing while a YouTube/SoundCloud embed was playing, since those
    // don't use audioEl at all.
    if (!hasLoadedTrack) return;
    document.getElementById('screen-nowplaying').classList.add('np-expanded');
  }
  function collapseNowPlaying(){
    document.getElementById('screen-nowplaying').classList.remove('np-expanded');
    stopYouTubeEmbed();
  }
  function closeNowPlaying(){
    stopYouTubeEmbed();
    if (isDesktop()) collapseNowPlaying();
    else goTo('playlist');
  }

  let isSeeking = false;
  audioEl.addEventListener('timeupdate', () => {
    if (isSeeking) return;
    const pct = audioEl.duration ? (audioEl.currentTime / audioEl.duration) * 100 : 0;
    document.getElementById('np-fill').style.width = pct + '%';
    document.getElementById('mb-fill').style.width = pct + '%';
    document.getElementById('np-elapsed').textContent = fmtTime(audioEl.currentTime);
    document.getElementById('mb-elapsed').textContent = fmtTime(audioEl.currentTime);
  });
  audioEl.addEventListener('loadedmetadata', () => {
    document.getElementById('np-duration').textContent = fmtTime(audioEl.duration);
    document.getElementById('mb-duration').textContent = fmtTime(audioEl.duration);
  });
  audioEl.addEventListener('ended', nextTrack);

  // ---- Seek by tapping/dragging the progress bar (forward or backward) ----
  function setupSeekBar(barId, fillId, elapsedId){
    const bar = document.getElementById(barId);
    const fill = document.getElementById(fillId);
    const elapsedEl = document.getElementById(elapsedId);

    function fractionFromEvent(e){
      const rect = bar.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      return Math.min(1, Math.max(0, x / rect.width));
    }
    function applyFraction(frac){
      fill.style.width = (frac * 100) + '%';
      if (playbackMode === 'soundcloud'){
        if (scDurationMs) elapsedEl.textContent = fmtTime((frac * scDurationMs) / 1000);
      } else if (audioEl.duration){
        elapsedEl.textContent = fmtTime(frac * audioEl.duration);
      }
    }

    bar.addEventListener('pointerdown', (e) => {
      if (playbackMode !== 'soundcloud' && !audioEl.duration) return;
      if (playbackMode === 'soundcloud' && !scDurationMs) return;
      isSeeking = true;
      bar.classList.add('seeking');
      bar.setPointerCapture(e.pointerId);
      applyFraction(fractionFromEvent(e));
    });
    bar.addEventListener('pointermove', (e) => {
      if (!isSeeking) return;
      applyFraction(fractionFromEvent(e));
    });
    function finishSeek(e){
      if (!isSeeking) return;
      isSeeking = false;
      bar.classList.remove('seeking');
      const frac = fractionFromEvent(e);
      if (playbackMode === 'soundcloud' && scWidget && scDurationMs){
        scWidget.seekTo(frac * scDurationMs);
      } else if (audioEl.duration){
        audioEl.currentTime = frac * audioEl.duration;
      }
    }
    bar.addEventListener('pointerup', finishSeek);
    bar.addEventListener('pointercancel', () => { isSeeking = false; bar.classList.remove('seeking'); });
  }
  setupSeekBar('np-bar', 'np-fill', 'np-elapsed');
  setupSeekBar('mb-bar', 'mb-fill', 'mb-elapsed');

  renderSidebarPlaylists();
  renderPlaylist('Sunset Drive', 'Playlist • Golden hour', ['#F5C453','#E0575B']);
  setPlayingIcons(false);
  loadSongsFromFirebase();

  setTimeout(() => {
    document.getElementById('splash').classList.add('hide');
  }, 1800);
